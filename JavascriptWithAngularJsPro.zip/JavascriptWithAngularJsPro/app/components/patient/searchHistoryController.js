hCueDoctorWebApp.lazyController('c7PatientSearchHistory', ['$scope', '$location', 'datacookieFactory', 'hcueLoginStatusService', 'alertify', '$uibModal', '$window', '$rootScope', 'c7SearchServices', 'referraldoctor', 'c7EnquiriesServices', 'hcueDoctorLoginService', 'c7AddUpdatePatient', 'c7Hl7ToMeshServices',
    function ($scope, $location, datacookieFactory, hcueLoginStatusService, alertify, $uibModal, $window, $rootScope, c7SearchServices, referraldoctor, c7EnquiriesServices, hcueDoctorLoginService, c7AddUpdatePatient, c7Hl7ToMeshServices) {

        var userLoginDetails = hcueLoginStatusService.getUserLoginDetails();

        userLoginDetails = datacookieFactory.getItem('loginData');
        if (userLoginDetails.loggedinStatus === "true") {
            $scope.setHeaderShouldShow(userLoginDetails.loggedinStatus);
        } else {
            $location.path('/login');
        }
        var doctorinfo = hcueDoctorLoginService.getDoctorInfo();

        if (doctorinfo.doctordata.doctorAddress[0].ExtDetails.HospitalInfo !== undefined && doctorinfo.doctordata.doctorAddress[0].ExtDetails.HospitalInfo.ParentHospitalID !== undefined) {
            parentHospitalId = doctorinfo.doctordata.doctorAddress[0].ExtDetails.HospitalInfo.ParentHospitalID;
            hospitalCode = doctorinfo.doctordata.doctorAddress[0].ExtDetails.HospitalInfo.HospitalCode;
            newRoleId = doctorinfo.doctordata.doctorAddress[0].ExtDetails.RoleID;
            docid = doctorinfo.doctorid;
        }
        $scope.clearSearchPatient = function () {
            $scope.searchPatient = '';
            $scope.showResult = false;
            $scope.searchCollection = [];
        }
        $scope.emailName = '';
        $scope.clearSearchPatient();
        $scope.searchCollection = [];
        $scope.searchshow = true;
        $scope.activeEnquiryId = undefined;
        $scope.search = function () {
            if ($scope.searchPatient == '') {
                return false;
            }

            c7SearchServices.searchPatientsget($scope.searchPatient, OnGetPatientSuccess, OnGetError);

            function OnGetPatientSuccess(data) {
                $scope.searchCollection = [];
                angular.forEach(data, function (i) {
                    var array_list = ['#af77c6', '#e4c120', '#69b3e7', '#ed9945', '#90c752'];
                    var val = array_list[Math.floor(Math.random() * array_list.length)];
                    i.colors = val;
                    $scope.searchCollection.push(i)
                })
                $scope.showResult = true;
            }
        }


        $scope.hover = function (fruit) {
            return fruit.showHover = !fruit.showHover;
        };

        $scope.viewCase = function (val) {
            $scope.activePatientId = val.patientid;
            $scope.searchshow = false;
            $scope.caseViewCollection = [];
            $scope.selectUserInfo = val;
            var params = {
                patientid: val.patientid,
                pagenumber: 0,
                pagesize: 1000
            }

            c7SearchServices.listPatientAllEnquiry(params, OnlistPatientAllEnquirySuccess, OnGetError);

            function OnlistPatientAllEnquirySuccess(data) {
                $scope.caseViewCollection = data;
                angular.forEach($scope.caseViewCollection, function (i, ind) {
                    if (ind == 0) {
                        i.isSelected = true;
                    } else {
                        i.isSelected = false;
                    }
                })
                $scope.detailedView($scope.caseViewCollection[0], 0)
            }

        }

        $scope.sublistSussessCount = 0;
        $scope.detailedView = function (data, index) {
            console.log(data, index)
            $scope.activeEnquiryId = data.patientenquiryid;
            $scope.activeLeftIndex = data.index;
            $scope.enquiriesCollection = [];
            angular.forEach($scope.caseViewCollection, function (j, ind) {
                if (index == ind) {
                    j.isSelected = true;
                } else {
                    j.isSelected = false;
                }
            })
            $scope.selectedCollection = data;
            var subParam = {
                patientenquiryid: data.patientenquiryid,
            }
            c7EnquiriesServices.listEnquiryStatus(subParam, listEnquiryStatusSuccess, OnGetError);
            c7EnquiriesServices.listAppointmentStatus(data.patientenquiryid + '/' + docid, subappointmentlistSuccess, OnGetError);

            $scope.enquiriesCollection = [];

            function listEnquiryStatusSuccess(data) {

                angular.forEach(data, function (val) {
                    val.dateNew = moment.utc(val.date, 'YYYY-MM-DD HH:mm:ss').local().format('DD-MM-YYYY HH:mm:ss');
                    val.timestamp = moment(val.date, 'YYYY-MM-DD HH:mm:ss').valueOf();
                    if (val.enquirystatusid == 'appemail' ||
                        val.enquirystatusid == 'appointEmail' ||
                        val.enquirystatusid == 'exclusion' ||
                        val.enquirystatusid == 'exclusionEmail' ||
                        val.enquirystatusid == 'declinedEmail' ||
                        val.enquirystatusid == 'patientDeclinedEmail' ||
                        val.enquirystatusid == 'dnaEmail' ||
                        val.enquirystatusid == 'contactusEmail' ||
                        val.enquirystatusid == 'nocontactEmail' ||
                        val.enquirystatusid == 'urgentnocontactEmail') {
                        val.emailobj = {
                            patientenquiryid: $scope.activeEnquiryId,
                            appointmentid: 0,
                            sendemail: true,
                            sendletter: true
                        }
                    }
                })
                $scope.enquiriesCollection = $scope.enquiriesCollection.concat(data);
                $scope.sublistSussessCount += 1;
                if ($scope.sublistSussessCount == 2) {
                    $scope.enquiriesCollection = $scope.enquiriesCollection.sort(function (a, b) {
                        return b.timestamp - a.timestamp;
                    });
                    $('#loaderDiv').hide();
                    $scope.sublistSussessCount = 0;
                }
                // angular.forEach(data, function (val) {
                //     val.date = moment.utc(val.date, 'YYYY-MM-DD HH:mm:ss').local().format('DD-MM-YYYY HH:mm:ss');
                //     val.timestamp = moment(val.date, 'YYYY-MM-DD HH:mm:ss').valueOf();
                // })
                // $scope.enquiriesCollection = $scope.enquiriesCollection.concat(data);
            }

            function subappointmentlistSuccess(data) {

                angular.forEach(data, function (val) {
                    val.dateNew = moment.utc(val.date, 'YYYY-MM-DD HH:mm:ss').local().format('DD-MM-YYYY HH:mm:ss');
                    val.timestamp = moment(val.date, 'YYYY-MM-DD HH:mm:ss').valueOf();
                    if (val.enquirystatusid == 'appointEmail' || val.enquirystatusid == 'exclusionEmail' || val.enquirystatusid == 'declinedEmail' || val.enquirystatusid == 'dnaEmail' || val.enquirystatusid == 'contactusEmail' || val.enquirystatusid == 'nocontactEmail' || val.enquirystatusid == 'urgentnocontactEmail') {
                        val.emailobj = {
                            patientenquiryid: $scope.activeEnquiryId,
                            appointmentid: 0,
                            sendemail: true,
                            sendletter: true
                        }
                    }
                })
                $scope.enquiriesCollection = $scope.enquiriesCollection.concat(data);
                $scope.sublistSussessCount += 1;
                if ($scope.sublistSussessCount == 2) {
                    $scope.enquiriesCollection = $scope.enquiriesCollection.sort(function (a, b) {
                        return b.timestamp - a.timestamp;
                    });
                    $scope.sublistSussessCount = 0;
                }
                // angular.forEach(data, function (val) {
                //     val.date = moment.utc(val.date, 'YYYY-MM-DD HH:mm:ss').local().format('DD-MM-YYYY HH:mm:ss');
                //     val.timestamp = moment(val.date, 'YYYY-MM-DD HH:mm:ss').valueOf();
                // })
                // $scope.enquiriesCollection = $scope.enquiriesCollection.concat(data);
            }

        }

        $scope.doctorDetails = function (id, val) {
            $scope.modalId = id;
            $scope.doctorInfo = [];
            referraldoctor.getdoctorDetails(val.referdoctorid, doctorDetailsSuccess, OnGetError);

            function doctorDetailsSuccess(data) {
                $scope.doctorInfo = data;

                if ($scope.modalId != '') {
                    $($scope.modalId).modal('show');
                    $scope.modalId = '';
                }
            }
        }



        function OnGetError(data) {

        }
        $scope.modalId = '';
        $scope.getPatientDetails = function (id) {
            $scope.modalId = id;
            var userParam = {
                PatientID: $scope.selectUserInfo.patientid,
                PatientEnquiryID: $scope.selectedCollection.patientenquiryid,
                USRId: doctorinfo.doctorid,
                USRType: "ADMIN",
                hospitalInfo: {
                    HospitalID: parentHospitalId,
                    HospitalCD: hospitalCode
                }
            }
            c7AddUpdatePatient.getPatientDetails(userParam, getpatientsuccess, OnGetError);

            function getpatientsuccess(data) {
                $scope.patientDetails = data;

                if ($scope.modalId != '') {
                    $($scope.modalId).modal('show');
                    $scope.modalId = '';
                }
            }
        }
        $scope.getsacnreport = function () {

        }

        $scope.sendemail = false;
        $scope.download = false;
        $scope.emailActoin = function (data, downloadcheck, email) {
            $scope.download = downloadcheck;
            $scope.sendemail = email;
            // data.patientenquiryid = eqid;
            if (data.enquirystatusid == 'appointEmail') {
                $scope.appointmentEmailTrue = true;
                $scope.emailName = 'Appointment Email';
                var submitData = {
                    patientenquiryid : data.patientenquiryid,
                    appointmentid : data.emailobj.appointmentid,
                    sendemail :email,
                    sendletter :downloadcheck,
                    appointmentdate : moment(data.appointmentdate).format('YYYY-MM-DD'),
                    appointmenttime : data.appointmenttime,
                    doctorid : data.doctorid,
                    appointmenthospitalid : data.appointmenthospitalid
                };
                c7EnquiriesServices.sendAppointmentEmail(submitData, emailactionSuccess, OnGetError);
            } else {
                $scope.appointmentEmailTrue = false;
            }
            if (data.enquirystatusid == 'declinedEmail') {
                $scope.emailName = 'Patient Declined Email';
                c7EnquiriesServices.sendPatientDeclinedEmail(data.emailobj, emailactionSuccess, OnGetError);
            }
            if (data.enquirystatusid == 'dnaEmail') {
                $scope.emailName = 'Patient DNA Email';
                c7EnquiriesServices.sendPatientDNAMail(data.emailobj, emailactionSuccess, OnGetError);
            }
            if (data.enquirystatusid == 'contactusEmail') {
                $scope.emailName = 'Contact Us Email';
                c7EnquiriesServices.sendContactUsEmail(data.emailobj, emailactionSuccess, OnGetError);
            }
            if (data.enquirystatusid == 'nocontactEmail') {
                $scope.emailName = 'No Contact To GP Email';
                c7EnquiriesServices.sendNoContactToGP(data.emailobj, emailactionSuccess, OnGetError);
            }
            if (data.enquirystatusid == 'urgentnocontactEmail') {
                $scope.emailName = 'Urgent No Contact To GP Email';
                data.emailobj['emailtype'] = 'URGENT';
                c7EnquiriesServices.sendNoContactToGP(data.emailobj, emailactionSuccess, OnGetError);
            }
            if (data.enquirystatusid == 'exclusionEmail') {
                $scope.emailName = 'Exclusion Email';
                c7EnquiriesServices.sendExclusionEmail(data.emailobj, emailactionSuccess, OnGetError);
            }
            if (data.enquirystatusid == 'patientDeclinedEmail') {
                $scope.emailName = 'Patient Withdrawal Email';
                data.emailobj.appointmentid = 0;
                c7EnquiriesServices.sendPatientWithdrawalMail(data.emailobj, emailactionSuccess, OnGetError);
            }
        }

        function emailactionSuccess(data) {
            if (data.includes('<!doctype html') && $scope.download) {
                $scope.printmail(data);
                $scope.download = false;
            } else if (!data.error && $scope.sendemail) {
                $scope.sendemail = false;
                alertify.success('Email Sent Successfully.');
            } else {
                alertify.error('Error in email sending.');
            }
        }

        $scope.printmail = function (data) {
            var html = data;

            var WindowObject = window.open("", "PrintWindow",
                "width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
            WindowObject.document.writeln(html.replace('Simple Transactional Email', $scope.emailName));
            WindowObject.document.close();
            setTimeout(function () {
                WindowObject.focus();
                if (!$scope.appointmentEmailTrue) {
                    WindowObject.print();
                    WindowObject.close();
                }
                $scope.appointmentEmailTrue = false;
            }, 2000)
            $scope.emailName = '';
        }
        $scope.sendpublishemail = function (data) {
            console.log(data);

            var params = {
                responseId: data.observationid,
                PracticeID: data.reportprcticeid,
            }
            c7Hl7ToMeshServices.sendAttachmentMail(params, publishSuccess, publishError);
        }

        function publishSuccess(data) {
            if (data == 'MESSAGE_ACCEPTED') {
                alertify.success('Published Successfully');
            } else if (data == 'Success') {
                alertify.success('Published Successfully & Email Sent');
            } else if (data == 'INVALID_MAILBOXID_AUTHENTICATION') {
                alertify.success('INVALID_MAILBOXID_AUTHENTICATION');
            }
            if (data.error) {
                publishError(data);
            }
        }

        function publishError(error) {
            if (error == 'INVALID_REFERENCE_ID') {
                alertify.error('Invalid Reference Id');
            } else if (error == 'REPORT_NOT_FOUND') {
                alertify.error('Report Not Found');
            } else if (error == 'MESSAGE_NOT_DELIVERY') {
                alertify.error('Message Not Delivered');
            } else if (error == 'INVALID_MAILBOXID_AUTHENTICATION') {
                alertify.error('Invalid MailBox Id');
            } else {
                alertify.error('Error Occurred');
            }
        }

        $('body').on('change', '#UploadDocument3', function (e) {
            var droppedFiles = e.target.files;
            uploadFile(droppedFiles);
        });

        uploadFile = function (data) {
            var file = data[0];

            if (file == undefined) {
                return;
            }
            var formData = new FormData();
            $scope.fileurl = file.name;

            formData.append("fileUpload", file);
            formData.append("typeDoc", "LettersDocument");
            formData.append("patientID", $scope.activePatientId);
            formData.append("patientenquiryID", $scope.activeEnquiryId);
            var ext = file.name.split('.');
            formData.append("fileExtn", ext[ext.length - 1].toLowerCase());
            $scope.fileType = ext[ext.length - 1];

            formData.append("timestamp", moment().valueOf());
            formData.append("fileName", file.name.toLowerCase());

            c7AddUpdatePatient.uploadLetterDocument(formData, uploadSuccess, uploadError);

            document.getElementById('UploadDocument3').value = '';

        }

        function uploadError(data) {
            alertify.error(data);
        }

        function uploadSuccess(data) {
            if (data.url) {
                alertify.success('Upload Success');
                uploadFileToEnquiry(data.url);
            } else {
                alertify.error('Upload Error');
            }
        }


        function uploadFileToEnquiry(urlString) {
            var uploadParam = {
                patientid: $scope.activePatientId,
                patientenquiryid: $scope.activeEnquiryId,
                usrid: doctorinfo.doctorid,
                statustypeid: "DocumentUpload",
                documenturl: urlString
            };

            c7EnquiriesServices.enquiryaddstatus(uploadParam, updateEnquiryStatus, uploadError);
        }
        function updateEnquiryStatus(data) {
            if (data != "Success") {
                alertify.error('Status update error');
            } else {
                $scope.detailedView($scope.caseViewCollection[0], $scope.activeLeftIndex);
            }
        }
        $scope.addnotes = function () {
            $scope.notesparam = {
                patientid: $scope.activePatientId,
                patientenquiryid: $scope.activeEnquiryId,
                usrid: doctorinfo.doctorid,
                statustypeid: "Notes",
                documenturl: undefined
            };
            console.log($scope.notesparam);
        }
        $scope.submitnotes = function () {
            $scope.notesparam['documenturl'] = $scope.Gnnotes;
            console.log($scope.notesparam);
            $('#notes').modal('hide');
            c7EnquiriesServices.enquiryaddstatus($scope.notesparam, updateEnquiryStatus, uploadError);
        }
    }
]);