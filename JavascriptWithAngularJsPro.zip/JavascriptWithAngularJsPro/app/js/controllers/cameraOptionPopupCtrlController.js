﻿hCueDoctorWebControllers.controller('CameraOptionPopupCtrl', ['$scope', '$timeout',
     function($scope, $timeout) {

         /* $ionicModal.fromTemplateUrl('camera-modal.html', {
              scope: $scope,
              animation: 'slide-in-up'
          }).then(function (modal) {
              $scope.modal = modal;
          });

          $scope.openModal = function () {
              $scope.modal.show();
          };

          $scope.closeModal = function () {
              $scope.modal.hide();
          };

          //Cleanup the modal when we're done with it!
          $scope.$on('$destroy', function () {
             // $scope.modal.remove();
          });
          // Execute action on hide modal
          $scope.$on('modal.hide', function () {
              // Execute action
          });
          // Execute action on remove modal
          $scope.$on('modal.removed', function () {
              // Execute action
          });
          $scope.$on('modal.shown', function () {
              // ////console.log('Modal is shown!');
          });

          $scope.imageSrc = "";

          $scope.showDocImage = function (srcpath) {
              //$scope.imageSrc = "data:image/png;base64," + srcpath;
              $scope.openModal();
          };
          var myPopup;
          $scope.ShowChoice = function () {
               
              myPopup = $ionicPopup.show({
                  template: '<div class="add-img-popup"><h4>Add a Image</h4><div class="add-img-action"><a ng-click="showOption(1)" class="icon-t-photo">Take a photo</a><a ng-click="showOption(2)" class="icon-choose-photo">Choose image</a></div></div>',
                    
                 // template: '<button ng-click="showOption(1)">Take a photo </button><br><button ng-click="showOption(2)">Choose File</button>',
                  title: 'Upload the documents',
                  subTitle: 'Please choose from below option',
                  scope: $scope

              });
              myPopup.then(function (res) {
                 // ////console.log('Tapped!', res);
              });
              $timeout(function () {
                  myPopup.close(); //close the popup after 3 seconds for some reason
              }, 5000);
          }
          $scope.showOption = function (n) {
              if (n == 1)
                  $scope.AddImage('capture');
              else
                  $scope.AddImage('choose');
              myPopup.close();
          }*/

     }
 ])